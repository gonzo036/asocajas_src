<?php

/*
  Template Name: Home Template
*/

	get_template_part('includes/header');


	get_template_part('includes/footer');