<?php

/*
  Template Name: Gremio Template
*/

	get_template_part('includes/header');


	get_template_part('includes/footer');